#pragma once
#include "Characters.h"

class Space :  public Characters
{
public:
	Space(int x, int y);
};

