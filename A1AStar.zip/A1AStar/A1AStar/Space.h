#pragma once
#include "Characters.h"
#define _CRTDBG_MAP_ALLOC

#include <crtdbg.h>
#include <stdlib.h>
class Space :  public Characters
{
public:
	Space(int x, int y);
};

