#include "Enemy.h"

Enemy::Enemy(int x, int y) {
	xPos = x;
	yPos = y;
	type = "Enemy";
}
