#pragma once
#include "Characters.h"
class Wall : public Characters
{
public:
	Wall(int x, int y);
	~Wall();
};

