#include "Characters.h"
#define _CRTDBG_MAP_ALLOC
#ifdef _DEBUG
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#else
#define DBG_NEW new
#endif

#include <crtdbg.h>
#include <stdlib.h>

Characters::Characters()
{
	xPos = 0;
	yPos = 0;
	moveCost = 0;
	parent = nullptr;
}

void Characters::updatePosition(int x, int y)
{
	xPos = x;
	yPos = y;
}

