#include "Space.h"
#include <crtdbg.h>
#include <stdlib.h>

Space::Space(int x, int y)
{
	type = "Space";
	xPos = x;
	yPos = y;
}
