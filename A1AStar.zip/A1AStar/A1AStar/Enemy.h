#pragma once
#include "Characters.h"
#include "Space.h"
#include <vector>
#define _CRTDBG_MAP_ALLOC
#ifdef _DEBUG
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#else
#define DBG_NEW new
#endif

#include <crtdbg.h>
#include <stdlib.h>
using namespace std;

class Enemy : public Characters
{
public:
	vector<Characters*> closedList;
	vector<Characters*> openList;

	Enemy(int x, int y);
	~Enemy();
};


