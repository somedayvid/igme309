#pragma once
#include "Characters.h"
class Player : public Characters
{
public:
	Player(int x, int y);
};

