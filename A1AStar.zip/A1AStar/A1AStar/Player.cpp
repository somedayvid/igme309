#include "Player.h"
#define _CRTDBG_MAP_ALLOC

#include <crtdbg.h>
#include <stdlib.h>

Player::Player(int x, int y)
{
	xPos = x;
	yPos = y;
	type = "Player";
	hCost = 0;
}
