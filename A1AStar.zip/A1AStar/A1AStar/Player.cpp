#include "Player.h"

Player::Player(int x, int y)
{
	xPos = x;
	yPos = y;
	type = "Player";
	hCost = 0;
}
