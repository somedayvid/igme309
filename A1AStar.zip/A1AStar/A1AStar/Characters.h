#pragma once
#include <string>
#define _CRTDBG_MAP_ALLOC
#ifdef _DEBUG
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#else
#define DBG_NEW new
#endif

#include <crtdbg.h>
#include <stdlib.h>
class Characters
{
public:
	unsigned short xPos;
	unsigned short yPos;
	int hCost;
	std::string type;
	int moveCost;
	Characters* parent;

	Characters();
	void updatePosition(int x, int y);
};

